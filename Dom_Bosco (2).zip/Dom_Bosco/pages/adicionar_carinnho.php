<?php
session_start();
include('../includes/db_connect.php');

// Recebe os dados enviados pelo JavaScript
$data = json_decode(file_get_contents('php://input'), true);

$idLivro = $data['idLivro'];
$quantidade = $data['quantidade'];
$idCliente = $_SESSION['idCliente'] ?? null;

if (!$idCliente) {
    echo json_encode(['success' => false, 'message' => 'Usuário não está logado.']);
    exit;
}

// Verifica se o livro já está no carrinho
$sqlVerifica = "SELECT idCarrinho, quantidade FROM carrinho WHERE idCliente = ? AND idLivro = ?";
$stmtVerifica = $conn->prepare($sqlVerifica);
$stmtVerifica->bind_param("ii", $idCliente, $idLivro);
$stmtVerifica->execute();
$result = $stmtVerifica->get_result();
$itemExistente = $result->fetch_assoc();

if ($itemExistente) {
    // Atualiza a quantidade do item no carrinho
    $novaQuantidade = $itemExistente['quantidade'] + $quantidade;
    $sqlAtualiza = "UPDATE carrinho SET quantidade = ? WHERE idCarrinho = ?";
    $stmtAtualiza = $conn->prepare($sqlAtualiza);
    $stmtAtualiza->bind_param("ii", $novaQuantidade, $itemExistente['idCarrinho']);
    $stmtAtualiza->execute();
} else {
    // Insere um novo item no carrinho
    $sqlInsere = "INSERT INTO carrinho (idCliente, idLivro, quantidade) VALUES (?, ?, ?)";
    $stmtInsere = $conn->prepare($sqlInsere);
    $stmtInsere->bind_param("iii", $idCliente, $idLivro, $quantidade);
    $stmtInsere->execute();
}

echo json_encode(['success' => true]);
?>
