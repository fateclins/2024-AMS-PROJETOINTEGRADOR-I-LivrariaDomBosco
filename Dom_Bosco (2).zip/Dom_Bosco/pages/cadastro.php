<?php
include('../includes/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomeCliente = $_POST['nome'];
    $emailCliente = $_POST['email'];
    $senhaCliente = $_POST['senha'];


    // Insere os dados do fornecedor no banco
    $sql = "INSERT INTO cliente (nomeCliente, emailCliente, senhaCliente) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $nomeCliente, $emailCliente, $senhaCliente);

    if ($stmt->execute()) {
        header('Location: login.php');
        exit;
    } else {
        $erro = "Erro ao cadastrar cliente!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Cliente - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="form-container">
            <div class="form-box">
                <h2>Cadastro (Cliente)</h2>
                <form method="post">
                    <input type="text" name="nome" placeholder="Nome do Cliente" required>
                    <input type="email" name="email" placeholder="Endereço de E-mail" required>
                    <input type="password" name="senha" placeholder="Senha" required>
                    <button type="submit">Cadastrar</button>
                    <?php if (isset($erro)) { echo "<p style='color: red;'>$erro</p>"; } ?>
                </form>
                <p>
                    Já tem uma conta? <a href="login.php">Faça login</a>.
                </p>
            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
