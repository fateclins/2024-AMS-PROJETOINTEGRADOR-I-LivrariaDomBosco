<?php
include('../includes/db_connect.php');

// Busca os itens do carrinho
$sql = "SELECT c.idCarrinho, c.quantidade, c.subtotal, p.nomeProduto, p.precoProduto, p.tipoProduto, p.idProduto 
        FROM carrinho c 
        JOIN produto p ON c.idProduto = p.idProduto";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="cart-container">
            <h2>Baú de Compras</h2>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Preço</th>
                        <th>Quantidade</th>
                        <th>Subtotal</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $result->fetch_assoc()) { ?>
                        <tr>
                            <td class="product-info">
                                <div>
                                    <h3><?php echo $item['nomeProduto']; ?></h3>
                                    <p><?php echo $item['tipoProduto']; ?></p>
                                </div>
                            </td>
                            <td>R$ <?php echo number_format($item['precoProduto'], 2, ',', '.'); ?></td>
                            <td><?php echo $item['quantidade']; ?></td>
                            <td>R$ <?php echo number_format($item['subtotal'], 2, ',', '.'); ?></td>
                            <td>
                                <a href="detalhes_produto.php?id=<?php echo $item['idProduto']; ?>" class="view-btn">Visualizar</a>
                                <a href="remover_carrinho.php?id=<?php echo $item['idCarrinho']; ?>" class="remove-btn">Remover</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>

