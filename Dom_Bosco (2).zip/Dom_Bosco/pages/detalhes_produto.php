<?php
include('../includes/db_connect.php');

// Obtém o ID do produto da URL (com validação)
$idProduto = $_GET['id'] ?? null;

$produto = null; // Inicializa a variável

if ($idProduto) {
    // Prepara e executa a consulta
    $sql = "SELECT * FROM produto WHERE idProduto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idProduto);
    $stmt->execute();
    $produto = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo $produto ? htmlspecialchars($produto['nomeProduto']) : 'Produto não encontrado'; ?>
    </title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="product-details">
            <?php if ($produto): ?>
                <h2><?php echo htmlspecialchars($produto['nomeProduto']); ?></h2>
                <p>Tipo: <?php echo htmlspecialchars($produto['tipoProduto']); ?></p>
                <p>Preço: R$ <?php echo number_format($produto['precoProduto'], 2, ',', '.'); ?></p>
                <p>Descrição: <?php echo !empty($produto['descricaoProduto']) ? htmlspecialchars($produto['descricaoProduto']) : 'Descrição não disponível.'; ?></p>
            <?php else: ?>
                <h2>Produto não encontrado</h2>
                <p>Desculpe, o produto que você está procurando não foi encontrado.</p>
            <?php endif; ?>
            <a href="carrinho.php" class="btn">Voltar para o Carrinho</a>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
