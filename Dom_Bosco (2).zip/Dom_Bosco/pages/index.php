<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>

    <main>
        <div class="store-container">
            <?php
            include('../includes/db_connect.php');
            $sql = "SELECT l.idLivro, l.nomeLivro, l.descricao, l.precoPorUnidade, c.nomeCategoria, l.imagem 
            FROM livros l
            LEFT JOIN categorias c ON l.idCategoria = c.idCategoria";
    
    $result = $conn->query($sql);
    
    while ($livro = $result->fetch_assoc()) {
        echo "<div class='product-card'>";
        if (!empty($livro['imagem'])) {
            echo "<img src='data:image/jpeg;base64," . base64_encode($livro['imagem']) . "' alt='{$livro['nomeLivro']}'>";
        } else {
            echo "<img src='../img/placeholder.png' alt='Imagem não disponível'>";
        }
        echo "<h3>{$livro['nomeLivro']}</h3>";
        echo "<p>{$livro['descricao']}</p>";
        echo "<p>R$ " . number_format($livro['precoPorUnidade'], 2, ',', '.') . "</p>";
        echo "<p>Categoria: {$livro['nomeCategoria']}</p>";
        echo "<a href='detalhe_livro.php?id={$livro['idLivro']}'><button>Ver Detalhes</button></a>";
        echo "</div>";
    }
    
            ?>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>


