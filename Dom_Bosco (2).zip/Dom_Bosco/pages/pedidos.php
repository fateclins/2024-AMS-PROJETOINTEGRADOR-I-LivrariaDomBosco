<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Dom Bosco</h1>
            <p>Livraria</p>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="O que você procura hoje?">
            <button>🔍</button>
        </div>
        <div class="cart">
            🛒
        </div>
    </header>
    <?php include('../includes/header.php'); ?>
<main>
    <div class="orders-container">
        <h2>Minha Conta</h2>
        <h3>Meus Pedidos</h3>
        <table>
            <thead>
                <tr>
                    <th>Pedido</th>
                    <th>Data</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>#000000</td>
                    <td>01 de Janeiro de 2024</td>
                    <td>Concluído</td>
                    <td>R$ 50,00 de 1 item</td>
                    <td><button>Visualizar</button></td>
                </tr>
                <tr>
                    <td>#000001</td>
                    <td>01 de Janeiro de 2024</td>
                    <td>Concluído</td>
                    <td>R$ 80,00 de 1 item</td>
                    <td><button>Visualizar</button></td>
                </tr>
            </tbody>
        </table>
    </div>
</main>
<?php include('../includes/footer.php'); ?>

</body>
</html>
