<?php
session_start();
include('../includes/db_connect.php');

// Obtém o ID do item do carrinho
$idCarrinho = $_GET['id'];

// Busca o ID do produto antes de removê-lo do carrinho
$sqlProduto = "SELECT idProduto, quantidade FROM carrinho WHERE idCarrinho = ?";
$stmtProduto = $conn->prepare($sqlProduto);
$stmtProduto->bind_param("i", $idCarrinho);
$stmtProduto->execute();
$produto = $stmtProduto->get_result()->fetch_assoc();

if ($produto) {
    $idProduto = $produto['idProduto'];
    $quantidade = $produto['quantidade'];

    // Remove o item do carrinho
    $sqlRemoverCarrinho = "DELETE FROM carrinho WHERE idCarrinho = ?";
    $stmtRemoverCarrinho = $conn->prepare($sqlRemoverCarrinho);
    $stmtRemoverCarrinho->bind_param("i", $idCarrinho);
    $stmtRemoverCarrinho->execute();

    // Atualiza a quantidade ou remove do perfil do cliente
    $sqlAtualizarPerfil = "
        UPDATE cliente_produto 
        SET quantidade = quantidade - ?
        WHERE idProduto = ? AND idCliente = ?
    ";
    $stmtAtualizarPerfil = $conn->prepare($sqlAtualizarPerfil);
    $stmtAtualizarPerfil->bind_param("iii", $quantidade, $idProduto, $_SESSION['idCliente']);
    $stmtAtualizarPerfil->execute();

    // Remove do perfil se a quantidade for 0
    $sqlRemoverPerfil = "DELETE FROM cliente_produto WHERE quantidade <= 0";
    $conn->query($sqlRemoverPerfil);
}

header("Location: carrinho.php");
exit;
?>

