<?php
session_start();
include('../includes/db_connect.php');

// Verifica se o fornecedor está logado
if (!isset($_SESSION['idFornecedor'])) {
    header('Location: login_fornecedor.php');
    exit;
}

$idLivro = $_GET['id'];
$sql = "DELETE FROM livros WHERE idLivro = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $idLivro);
$stmt->execute();

header('Location: painel_fornecedor.php');
exit;
?>
