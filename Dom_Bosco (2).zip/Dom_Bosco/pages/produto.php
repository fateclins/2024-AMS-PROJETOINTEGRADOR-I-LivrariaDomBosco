<?php
include('../includes/db_connect.php');

// Obtém o ID do produto via URL
$idProduto = $_GET['id'] ?? 0;

// Busca os detalhes do produto no banco de dados
$sql = "SELECT * FROM produto WHERE idProduto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $idProduto);
$stmt->execute();
$result = $stmt->get_result();
$produto = $result->fetch_assoc();

// Redireciona para a loja caso o produto não exista
if (!$produto) {
    header('Location: loja.php');
    exit;
}

// Adiciona o produto ao carrinho e ao perfil
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quantidade = $_POST['quantidade'];
    $subtotal = $quantidade * $produto['precoProduto'];

    // Adiciona no carrinho
    $sqlCarrinho = "INSERT INTO carrinho (idProduto, quantidade, subtotal) VALUES (?, ?, ?)";
    $stmtCarrinho = $conn->prepare($sqlCarrinho);
    $stmtCarrinho->bind_param('iid', $idProduto, $quantidade, $subtotal);

    // Verifica se o cliente está logado (usuário autenticado)
    session_start(); // Inicia a sessão (caso não tenha sido iniciada)
    $idCliente = $_SESSION['idCliente'] ?? null;

    if ($idCliente) {
        // Adiciona no perfil (cliente_produto)
        $sqlClienteProduto = "
            INSERT INTO cliente_produto (idCliente, idProduto, quantidade) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade)";
        $stmtClienteProduto = $conn->prepare($sqlClienteProduto);
        $stmtClienteProduto->bind_param('iii', $idCliente, $idProduto, $quantidade);
    }

    // Executa as queries
    if ($stmtCarrinho->execute() && ($stmtClienteProduto->execute() ?? true)) {
        header('Location: carrinho.php'); // Redireciona para o carrinho
        exit;
    } else {
        $erro = "Erro ao adicionar ao carrinho.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $produto['nomeProduto']; ?> - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="product-container">
            <div class="product-image">
                <img src="../img/<?php echo $produto['nomeProduto']; ?>.jpg" alt="<?php echo $produto['nomeProduto']; ?>">
            </div>
            <div class="product-details">
                <h1><?php echo $produto['nomeProduto']; ?></h1>
                <p class="category">Categoria: <span><?php echo $produto['tipoProduto']; ?></span></p>
                <p class="price">R$ <?php echo $produto['precoProduto']; ?></p>
                <p class="installments">Ou em até 2x de <span>R$ <?php echo number_format($produto['precoProduto'] / 2, 2, ',', '.'); ?></span> sem juros</p>

                <!-- Formulário para adicionar ao carrinho -->
                <form method="post">
                    <div class="quantity">
                        <button type="button" onclick="alterarQuantidade(-1)">-</button>
                        <input type="number" name="quantidade" value="1" min="1" id="quantidade">
                        <button type="button" onclick="alterarQuantidade(1)">+</button>
                    </div>
                    <button type="submit" class="add-to-cart-btn">🛒 Adicionar ao Carrinho</button>
                    <?php if (isset($erro)) { echo "<p style='color: red;'>$erro</p>"; } ?>
                </form>
            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>

    <script>
        function alterarQuantidade(valor) {
            const input = document.getElementById('quantidade');
            const novaQuantidade = parseInt(input.value) + valor;
            if (novaQuantidade >= 1) {
                input.value = novaQuantidade;
            }
        }
    </script>
</body>
</html>



