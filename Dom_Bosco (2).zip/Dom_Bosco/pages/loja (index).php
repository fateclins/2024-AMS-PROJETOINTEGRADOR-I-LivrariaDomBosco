<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="store-container">
            <div class="product-card">
                <img src="../img/sherlock-holmes.jpg" alt="Sherlock Holmes - Coleção Completa">
                <h3>Coleção Completa Sherlock Holmes</h3>
                <p>R$ 80,00</p>
                <button>Comprar</button>
            </div>
            <div class="product-card">
                <img src="../img/sandman.jpg" alt="Sandman Vol.1">
                <h3>Sandman Vol.1 Edição Definitiva</h3>
                <p>R$ 60,00</p>
                <button>Comprar</button>
            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>

