<?php
session_start(); // Para verificar informações do usuário logado
include('../includes/db_connect.php');

// Verifica se o cliente está logado
$idCliente = $_SESSION['idCliente'] ?? null;

if (!$idCliente) {
    echo "Erro: Cliente não está logado.";
    exit;
}

// Busca informações do cliente
$sqlCliente = "SELECT * FROM cliente WHERE idCliente = ?";
$stmtCliente = $conn->prepare($sqlCliente);
$stmtCliente->bind_param("i", $idCliente);
$stmtCliente->execute();
$cliente = $stmtCliente->get_result()->fetch_assoc();

// Busca produtos adicionados ao perfil do cliente
// Busca produtos adicionados ao perfil do cliente
$sql = "
SELECT cp.idProduto, l.nomeLivro AS nomeProduto, l.precoPorUnidade AS precoProduto, cp.quantidade, 
       (cp.quantidade * l.precoPorUnidade) AS subtotal
FROM cliente_produto cp
JOIN livros l ON cp.idProduto = l.idLivro
WHERE cp.idCliente = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idCliente);
$stmt->execute();
$produtosPedidos = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="profile-container">
            <h2>Minha Conta</h2>
            <div class="profile-info">
                <p><strong>Nome:</strong> <?php echo htmlspecialchars($cliente['nomeCliente']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($cliente['emailCliente']); ?></p>
            </div>
            <h3>Meus Produtos</h3>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Preço</th>
                        <th>Quantidade</th>
                        <th>Subtotal</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($produto = $produtosPedidos->fetch_assoc()) { ?>
                        <tr>
                            <td class="product-info">
                                <div>
                                    <h3><?php echo htmlspecialchars($produto['nomeProduto']); ?></h3>
                                    <p><?php echo htmlspecialchars($produto['tipoProduto']); ?></p>
                                </div>
                            </td>
                            <td>R$ <?php echo number_format($produto['precoProduto'], 2, ',', '.'); ?></td>
                            <td><?php echo $produto['quantidade']; ?></td>
                            <td>R$ <?php echo number_format($produto['subtotal'], 2, ',', '.'); ?></td>
                            <td>
                                <a href="carrinho.php?id=<?php echo $produto['idProduto']; ?>" class="view-btn">Visualizar</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
