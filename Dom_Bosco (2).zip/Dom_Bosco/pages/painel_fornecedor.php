<?php
session_start();
include('../includes/db_connect.php');

// Verifica se o fornecedor está logado
if (!isset($_SESSION['idFornecedor'])) {
    header('Location: login_fornecedor.php');
    exit;
}

// Adicionar livro ao banco de dados
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomeLivro = $_POST['nomeLivro'];
    $descricao = $_POST['descricao'];
    $quantidade = $_POST['quantidade'];
    $preco = $_POST['precoPorUnidade'];
    $idCategoria = $_POST['idCategoria'];
    $idFornecedor = $_SESSION['idFornecedor'];

    // Manipulação de imagem
    $imagem = null;
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $imagem = file_get_contents($_FILES['imagem']['tmp_name']); // Converte a imagem para binário
    }

    // Insere no banco de dados
    $sql = "INSERT INTO livros (idFornecedor, nomeLivro, descricao, quantidade, precoPorUnidade, idCategoria, imagem) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('issidis', $idFornecedor, $nomeLivro, $descricao, $quantidade, $preco, $idCategoria, $imagem);
    $stmt->execute();

    header('Location: painel_fornecedor.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Fornecedor</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="fornecedor-panel">
            <h2>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nomeFornecedor']); ?></h2>
            <h3>Gerenciar Livros</h3>

            <!-- Formulário para adicionar livros -->
            <form method="post" class="book-form" enctype="multipart/form-data">
                <h3>Adicionar Novo Livro</h3>
                <input type="text" name="nomeLivro" placeholder="Nome do Livro" required>
                <textarea name="descricao" placeholder="Descrição do Livro" required></textarea>
                <input type="number" name="quantidade" placeholder="Quantidade" min="1" required>
                <input type="number" step="0.01" name="precoPorUnidade" placeholder="Preço por Unidade" required>
                <select name="idCategoria" required>
                    <option value="" disabled selected>Selecione uma Categoria</option>
                    <?php
                    $sqlCategorias = "SELECT * FROM categorias";
                    $resultCategorias = $conn->query($sqlCategorias);
                    while ($categoria = $resultCategorias->fetch_assoc()) {
                        echo "<option value='{$categoria['idCategoria']}'>{$categoria['nomeCategoria']}</option>";
                    }
                    ?>
                </select>
                <input type="file" name="imagem" accept="image/*" required>
                <button type="submit">Adicionar Livro</button>
            </form>

            <!-- Listar livros do fornecedor -->
            <div class="book-list">
                <h3>Seus Livros</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Quantidade</th>
                            <th>Preço</th>
                            <th>Descrição</th>
                            <th>Categoria</th>
                            <th>Imagem</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $idFornecedor = $_SESSION['idFornecedor'];
                        $sql = "
                            SELECT livros.*, categorias.nomeCategoria 
                            FROM livros 
                            LEFT JOIN categorias ON livros.idCategoria = categorias.idCategoria 
                            WHERE idFornecedor = ?
                        ";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param('i', $idFornecedor);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        while ($livro = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($livro['nomeLivro']) . "</td>";
                            echo "<td>{$livro['quantidade']}</td>";
                            echo "<td>R$ " . number_format($livro['precoPorUnidade'], 2, ',', '.') . "</td>";
                            echo "<td>" . htmlspecialchars($livro['descricao']) . "</td>";
                            echo "<td>" . ($livro['nomeCategoria'] ?? 'Sem Categoria') . "</td>";
                            echo "<td>";
                            if (!empty($livro['imagem'])) {
                                echo "<img src='data:image/jpeg;base64," . base64_encode($livro['imagem']) . "' alt='Imagem do Livro' style='max-width:100px; max-height:100px;'>";
                            } else {
                                echo "Sem imagem";
                            }
                            echo "</td>";
                            echo "<td><a href='remover_livro.php?id={$livro['idLivro']}' class='remove-btn'>Remover</a></td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
