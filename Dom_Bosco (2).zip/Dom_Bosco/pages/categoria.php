<?php
include('../includes/db_connect.php');

// Obtém a categoria pela URL
$categoria = $_GET['tipo'] ?? '';

// Busca os produtos dessa categoria
$sql = "SELECT * FROM produto WHERE tipoProduto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $categoria);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categoria: <?php echo htmlspecialchars($categoria); ?> - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="store-container">
            <h2>Categoria: <?php echo htmlspecialchars($categoria); ?></h2>
            <?php while ($produto = $result->fetch_assoc()) { ?>
                <div class="product-card">
                    <img src="../img/<?php echo $produto['nomeProduto']; ?>.jpg" alt="<?php echo $produto['nomeProduto']; ?>">
                    <h3><?php echo $produto['nomeProduto']; ?></h3>
                    <p>R$ <?php echo $produto['precoProduto']; ?></p>
                    <a href="produto.php?id=<?php echo $produto['idProduto']; ?>"><button>Ver Produto</button></a>
                </div>
            <?php } ?>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
