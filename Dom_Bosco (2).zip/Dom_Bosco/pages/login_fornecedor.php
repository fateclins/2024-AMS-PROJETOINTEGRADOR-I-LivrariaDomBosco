<?php
session_start();
include('../includes/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verifica as credenciais
    $sql = "SELECT * FROM fornecedor WHERE emailFornecedor = ? AND senhaFornecedor = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $email, $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $fornecedor = $result->fetch_assoc();
        $_SESSION['idFornecedor'] = $fornecedor['idFornecedor'];
        $_SESSION['nomeFornecedor'] = $fornecedor['nomeFornecedor'];
        header('Location: painel_fornecedor.php');
        exit;
    } else {
        $erro = "Credenciais inválidas!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Fornecedor - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="form-container">
            <div class="form-box">
                <h2>Login (Fornecedor)</h2>
                <form method="post">
                    <input type="email" name="email" placeholder="Endereço de E-mail" required>
                    <input type="password" name="senha" placeholder="Senha" required>
                    <button type="submit">Entrar</button>
                    <?php if (isset($erro)) { echo "<p style='color: red;'>$erro</p>"; } ?>
                </form>
                <p>
                    Não tem uma conta? <a href="cadastro_fornecedor.php">Cadastre-se</a>.
                </p>
            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
