<?php
include('../includes/db_connect.php');

// Obtendo o ID do livro via GET
$idLivro = $_GET['id'] ?? null;

if ($idLivro) {
    // Buscando os detalhes do livro no banco de dados
    $sqlLivro = "SELECT * FROM livros WHERE idLivro = ?";
    $stmt = $conn->prepare($sqlLivro);
    $stmt->bind_param("i", $idLivro);
    $stmt->execute();
    $livro = $stmt->get_result()->fetch_assoc();
}

// Caso o livro não seja encontrado
if (!$livro) {
    echo "Livro não encontrado.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($livro['nomeLivro']); ?> - Dom Bosco Livraria</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="book-detail-container">
            <div class="book-info">
                <h1><?php echo htmlspecialchars($livro['nomeLivro']); ?></h1>
                <p><strong>Quantidade disponível:</strong> <?php echo htmlspecialchars($livro['quantidade']); ?></p>
                <p class="price">
                    <strong>R$ <?php echo number_format($livro['precoPorUnidade'], 2, ',', '.'); ?></strong>
                </p>
                <p class="installments">
                    Ou em até <strong>2x de R$<?php echo number_format($livro['precoPorUnidade'] / 2, 2, ',', '.'); ?></strong> sem juros
                </p>
                <div class="quantity-control">
                    <label for="quantity">Quantidade:</label>
                    <input type="number" id="quantity" name="quantity" value="1" min="1">
                </div>
                <form action="adicionar_carrinho.php" method="POST">
    <input type="hidden" name="idProduto" value="<?php echo $produto['idProduto']; ?>">
    <input type="number" name="quantidade" value="1" min="1">
    <button type="submit">Adicionar ao Carrinho</button>
</form>

            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>

    <script>
        function addToCart(idLivro) {
            const quantidade = document.getElementById('quantity').value;

            fetch('adicionar_carrinho.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ idLivro, quantidade })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Livro adicionado ao carrinho!');
                } else {
                    alert('Erro ao adicionar ao carrinho.');
                }
            });
        }
    </script>
</body>
</html>
