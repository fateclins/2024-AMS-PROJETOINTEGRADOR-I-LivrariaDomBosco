<?php
include('../includes/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $razaoSocial = $_POST['razaoSocial'];
    $cnpj = $_POST['cnpj'];

    // Insere os dados do fornecedor no banco
    $sql = "INSERT INTO fornecedor (nomeFornecedor, emailFornecedor, senhaFornecedor, razaoSocial, cnpj) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssss', $nome, $email, $senha, $razaoSocial, $cnpj);

    if ($stmt->execute()) {
        header('Location: login_fornecedor.php');
        exit;
    } else {
        $erro = "Erro ao cadastrar fornecedor!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Fornecedor - Dom Bosco</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include('../includes/header.php'); ?>
    <main>
        <div class="form-container">
            <div class="form-box">
                <h2>Cadastro (Fornecedor)</h2>
                <form method="post">
                    <input type="text" name="nome" placeholder="Nome do Fornecedor" required>
                    <input type="email" name="email" placeholder="Endereço de E-mail" required>
                    <input type="password" name="senha" placeholder="Senha" required>
                    <input type="text" name="razaoSocial" placeholder="Razão Social" required>
                    <input type="text" name="cnpj" placeholder="CNPJ" required>
                    <button type="submit">Cadastrar</button>
                    <?php if (isset($erro)) { echo "<p style='color: red;'>$erro</p>"; } ?>
                </form>
                <p>
                    Já tem uma conta? <a href="login_fornecedor.php">Faça login</a>.
                </p>
            </div>
        </div>
    </main>
    <?php include('../includes/footer.php'); ?>
</body>
</html>
