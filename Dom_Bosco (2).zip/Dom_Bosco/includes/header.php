<header>
    <div class="header-container">
        <div class="logo">
            <h1>Dom Bosco</h1>
            <p>Livraria</p>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="O que você procura hoje?">
            <button>🔍</button>
        </div>
        <div class="nav-icons">
            <a href="carrinho.php" title="Carrinho" class="icon">🛒</a>
            <a href="perfil.php" title="Perfil" class="icon">👤</a>
        </div>
    </div>
    <nav class="nav-menu">
        <a href="login.php">Login</a>
        <a href="cadastro.php">Cadastro</a>
        <a href="index.php">Loja</a>
    </nav>
</header>
