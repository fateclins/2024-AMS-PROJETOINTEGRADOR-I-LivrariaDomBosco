<?php
$servername = "localhost";
$username = "root"; // Insira seu usuário do banco de dados
$password = ""; // Insira sua senha do banco de dados
$dbname = "livraria_dom_bosco";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica se a conexão falhou
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
