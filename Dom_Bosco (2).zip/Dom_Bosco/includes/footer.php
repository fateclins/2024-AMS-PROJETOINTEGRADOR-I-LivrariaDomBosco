<footer>
        <div class="footer-container">
            <p>&copy; 2024 Dom Bosco - Livraria. Todos os direitos reservados.</p>
            <div class="footer-links">
                <a href="politica-privacidade.php">Política de Privacidade</a>
                <a href="termos.php">Termos de Uso</a>
                <a href="contato.php">Contato</a>
            </div>
        </div>
    </footer>
</body>
</html>
