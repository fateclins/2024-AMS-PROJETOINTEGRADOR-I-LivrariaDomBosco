<!DOCTYPE html>
<html>
<head>
    <title>Livraria Online - CRUD</title>
</head>
<body>
    <h1>CRUD da Livraria Online</h1>
    <h2>Clientes</h2>
    <?php include 'clientes.php'; ?>

    <h2>Fornecedores</h2>
    <?php include 'fornecedores.php'; ?>

    <h2>Produtos</h2>
    <?php include 'produtos.php'; ?>

    <h2>Pedidos</h2>
    <?php include 'pedidos.php'; ?>
</body>
</html>