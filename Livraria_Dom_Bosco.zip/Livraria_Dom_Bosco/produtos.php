<?php
include 'db.php';

// CREATE
if (isset($_POST['create_produto'])) {
    $nome = $_POST['nomeProduto'];
    $tipo = $_POST['tipoProduto'];
    $stmt = $pdo->prepare("INSERT INTO Produto (nomeProduto, tipoProduto) VALUES (?, ?)");
    $stmt->execute([$nome, $tipo]);
}

// READ
$produtos = $pdo->query("SELECT * FROM Produto")->fetchAll(PDO::FETCH_ASSOC);

// UPDATE
if (isset($_POST['update_produto'])) {
    $id = $_POST['idProduto'];
    $nome = $_POST['nomeProduto'];
    $tipo = $_POST['tipoProduto'];
    $stmt = $pdo->prepare("UPDATE Produto SET nomeProduto = ?, tipoProduto = ? WHERE idProduto = ?");
    $stmt->execute([$nome, $tipo, $id]);
}

// DELETE
if (isset($_POST['delete_produto'])) {
    $id = $_POST['idProduto'];
    $stmt = $pdo->prepare("DELETE FROM Produto WHERE idProduto = ?");
    $stmt->execute([$id]);
}
?>
<!-- HTML para interações com Produto -->
<form method="POST">
    <input type="text" name="nomeProduto" placeholder="Nome" required>
    <input type="text" name="tipoProduto" placeholder="Tipo" required>
    <button type="submit" name="create_produto">Adicionar Produto</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Ações</th>
    </tr>
    <?php foreach ($produtos as $produto): ?>
        <tr>
            <td><?= $produto['idProduto'] ?></td>
            <td><?= $produto['nomeProduto'] ?></td>
            <td><?= $produto['tipoProduto'] ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="idProduto" value="<?= $produto['idProduto'] ?>">
                    <button type="submit" name="delete_produto">Remover</button>
                </form>
                <button onclick="editProduto(<?= $produto['idProduto'] ?>, '<?= $produto['nomeProduto'] ?>', '<?= $produto['tipoProduto'] ?>')">Editar</button>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
function editProduto(id, nome, tipo) {
    document.querySelector('[name="idProduto"]').value = id;
    document.querySelector('[name="nomeProduto"]').value = nome;
    document.querySelector('[name="tipoProduto"]').value = tipo;
}
</script>