<?php
include 'db.php';

// CREATE
if (isset($_POST['create_cliente'])) {
    $nome = $_POST['nomeCliente'];
    $email = $_POST['emailCliente'];
    $senha = $_POST['senhaCliente'];
    $stmt = $pdo->prepare("INSERT INTO Cliente (nomeCliente, emailCliente, senhaCliente) VALUES (?, ?, ?)");
    $stmt->execute([$nome, $email, $senha]);
}

// READ
$clientes = $pdo->query("SELECT * FROM Cliente")->fetchAll(PDO::FETCH_ASSOC);

// UPDATE
if (isset($_POST['update_cliente'])) {
    $id = $_POST['idCliente'];
    $nome = $_POST['nomeCliente'];
    $email = $_POST['emailCliente'];
    $stmt = $pdo->prepare("UPDATE Cliente SET nomeCliente = ?, emailCliente = ? WHERE idCliente = ?");
    $stmt->execute([$nome, $email, $id]);
}

// DELETE
if (isset($_POST['delete_cliente'])) {
    $id = $_POST['idCliente'];
    $stmt = $pdo->prepare("DELETE FROM Cliente WHERE idCliente = ?");
    $stmt->execute([$id]);
}
?>
<!-- HTML para interações com Cliente -->
<form method="POST">
    <input type="text" name="nomeCliente" placeholder="Nome" required>
    <input type="email" name="emailCliente" placeholder="Email" required>
    <input type="password" name="senhaCliente" placeholder="Senha" required>
    <button type="submit" name="create_cliente">Adicionar Cliente</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Ações</th>
    </tr>
    <?php foreach ($clientes as $cliente): ?>
        <tr>
            <td><?= $cliente['idCliente'] ?></td>
            <td><?= $cliente['nomeCliente'] ?></td>
            <td><?= $cliente['emailCliente'] ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="idCliente" value="<?= $cliente['idCliente'] ?>">
                    <button type="submit" name="delete_cliente">Remover</button>
                </form>
                <button onclick="editCliente(<?= $cliente['idCliente'] ?>, '<?= $cliente['nomeCliente'] ?>', '<?= $cliente['emailCliente'] ?>')">Editar</button>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
function editCliente(id, nome, email) {
    document.querySelector('[name="idCliente"]').value = id;
    document.querySelector('[name="nomeCliente"]').value = nome;
    document.querySelector('[name="emailCliente"]').value = email;
}
</script>