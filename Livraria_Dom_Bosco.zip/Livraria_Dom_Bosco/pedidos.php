<?php
include 'db.php';

// CREATE
if (isset($_POST['create_pedido'])) {
    $nome = $_POST['nomePedido'];
    $tipo = $_POST['tipoPedido'];
    $stmt = $pdo->prepare("INSERT INTO Pedido (nomePedido, tipoPedido) VALUES (?, ?)");
    $stmt->execute([$nome, $tipo]);
}

// READ
$pedidos = $pdo->query("SELECT * FROM Pedido")->fetchAll(PDO::FETCH_ASSOC);

// UPDATE
if (isset($_POST['update_pedido'])) {
    $id = $_POST['idPedido'];
    $nome = $_POST['nomePedido'];
    $tipo = $_POST['tipoPedido'];
    $stmt = $pdo->prepare("UPDATE Pedido SET nomePedido = ?, tipoPedido = ? WHERE idPedido = ?");
    $stmt->execute([$nome, $tipo, $id]);
}

// DELETE
if (isset($_POST['delete_pedido'])) {
    $id = $_POST['idPedido'];
    $stmt = $pdo->prepare("DELETE FROM Pedido WHERE idPedido = ?");
    $stmt->execute([$id]);
}
?>
<!-- HTML para interações com Pedido -->
<form method="POST">
    <input type="text" name="nomePedido" placeholder="Nome do Pedido" required>
    <input type="text" name="tipoPedido" placeholder="Tipo do Pedido" required>
    <button type="submit" name="create_pedido">Adicionar Pedido</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Ações</th>
    </tr>
    <?php foreach ($pedidos as $pedido): ?>
        <tr>
            <td><?= $pedido['idPedido'] ?></td>
            <td><?= $pedido['nomePedido'] ?></td>
            <td><?= $pedido['tipoPedido'] ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="idPedido" value="<?= $pedido['idPedido'] ?>">
                    <button type="submit" name="delete_pedido">Remover</button>
                </form>
                <button onclick="editPedido(<?= $pedido['idPedido'] ?>, '<?= $pedido['nomePedido'] ?>', '<?= $pedido['tipoPedido'] ?>')">Editar</button>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
function editPedido(id, nome, tipo) {
    document.querySelector('[name="idPedido"]').value = id;
    document.querySelector('[name="nomePedido"]').value = nome;
    document.querySelector('[name="tipoPedido"]').value = tipo;
}
</script>