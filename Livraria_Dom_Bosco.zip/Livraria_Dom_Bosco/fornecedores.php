<?php
include 'db.php';

// CREATE
if (isset($_POST['create_fornecedor'])) {
    $nome = $_POST['nomeFornecedor'];
    $email = $_POST['emailFornecedor'];
    $senha = $_POST['senhaFornecedor'];
    $stmt = $pdo->prepare("INSERT INTO Fornecedor (nomeFornecedor, emailFornecedor, senhaFornecedor) VALUES (?, ?, ?)");
    $stmt->execute([$nome, $email, $senha]);
}

// READ
$fornecedores = $pdo->query("SELECT * FROM Fornecedor")->fetchAll(PDO::FETCH_ASSOC);

// UPDATE
if (isset($_POST['update_fornecedor'])) {
    $id = $_POST['idFornecedor'];
    $nome = $_POST['nomeFornecedor'];
    $stmt = $pdo->prepare("UPDATE Fornecedor SET nomeFornecedor = ? WHERE idFornecedor = ?");
    $stmt->execute([$nome, $id]);
}

// DELETE
if (isset($_POST['delete_fornecedor'])) {
    $id = $_POST['idFornecedor'];
    $stmt = $pdo->prepare("DELETE FROM Fornecedor WHERE idFornecedor = ?");
    $stmt->execute([$id]);
}
?>
<!-- HTML para interações com Fornecedor -->
<form method="POST">
    <input type="text" name="nomeFornecedor" placeholder="Nome" required>
    <input type="email" name="emailFornecedor" placeholder="Email" required>
    <input type="password" name="senhaFornecedor" placeholder="Senha" required>
    <button type="submit" name="create_fornecedor">Adicionar Fornecedor</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Ações</th>
    </tr>
    <?php foreach ($fornecedores as $fornecedor): ?>
        <tr>
            <td><?= $fornecedor['idFornecedor'] ?></td>
            <td><?= $fornecedor['nomeFornecedor'] ?></td>
            <td><?= $fornecedor['emailFornecedor'] ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="idFornecedor" value="<?= $fornecedor['idFornecedor'] ?>">
                    <button type="submit" name="delete_fornecedor">Remover</button>
                </form>
                <button onclick="editFornecedor(<?= $fornecedor['idFornecedor'] ?>, '<?= $fornecedor['nomeFornecedor'] ?>')">Editar</button>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
function editFornecedor(id, nome) {
    document.querySelector('[name="idFornecedor"]').value = id;
    document.querySelector('[name="nomeFornecedor"]').value = nome;
}
</script>